# TEMPLATES

## Template de composant React JS

```
import React from 'react'

export const Composant = () => {
  // ====== PARAMETRAGE ====== //

  // ====== VARIABLES ====== //

  // ====== REQUETES ====== //

  // ====== METHODES ====== //

  // ====== USE EFFECT ====== //

  // ====== COMPOSANTS ====== //

  // ====== AFFICHAGE ====== //

  return (
    <React.Fragment>
      <div>Composant</div>
    </React.Fragment>
  )
}

```