import React, {useState} from 'react'
import AfficherComposant from '../composants/AfficherComposant'
import {AlertDialog} from '../composants/AlertDialog'
import {CONSTANTES} from '../constantes/constantes'
import {useGetById} from '../api/api-generique'

export const ChoixToken = () => {
  const [afficherToken, setAfficherToken] = useState(false)

  const [token, setToken] = useState({})

  /** Permet d'effectuer une requête en bdd pour récupérer les utilisateurs */
  const {data: getUtilisateurs} = useGetById(CONSTANTES.entities.utilisateurs, [
    CONSTANTES.entities.utilisateurs,
  ])

  /** Permet d'effectuer une requête en bdd pour récupérer les utilisateurs */
  const {data: getProfils} = useGetById(CONSTANTES.entities.profils, [
    CONSTANTES.entities.profils,
  ])
  /** Permet d'effectuer une requête en bdd pour récupérer les utilisateurs */
  const {data: getDroits} = useGetById(CONSTANTES.entities.droits, [
    CONSTANTES.entities.droits,
  ])

  const handleOpen = () => {
    setAfficherToken(() => false)
  }

  const handleChangerToken = identifiant => {
    localStorage.setItem('X-Remote-User', identifiant)
    document.location.reload()
  }

  const handleDechiffrerToken = () => {
    const identifiant = localStorage.getItem('X-Remote-User')
    const utilisateur = getUtilisateurs.find(u => u.identifiant === identifiant)
    const profil = getProfils.find(p => p.id === utilisateur.profil)
    const droits = getDroits.filter(d => profil.droits.some(du => d.id === du))
    setToken({
      ...utilisateur,
      profil,
      droits,
    })
    setAfficherToken(prevState => !prevState.open)
  }

  return (
    <AfficherComposant condition={process.env.NODE_ENV === 'development'}>
      <select
        style={{marginRight: '10px'}}
        onChange={event => handleChangerToken(event.target.value)}
        defaultValue={localStorage.getItem('X-Remote-User')}
      >
        {getUtilisateurs?.map((utilisateur, index) => (
          <option key={index} value={utilisateur.identifiant}>
            {utilisateur.prenom}
          </option>
        ))}
      </select>
      <button
        disabled={!(getUtilisateurs && getProfils && getDroits)}
        onClick={handleDechiffrerToken}
      >
        TOKEN
      </button>
      <AlertDialog
        open={afficherToken}
        titre={'Token'}
        contenu={JSON.stringify(token, null, '\t')}
        handleOpen={handleOpen}
      />
    </AfficherComposant>
  )
}
