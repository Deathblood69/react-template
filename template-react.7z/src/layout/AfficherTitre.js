import {Button} from '@mui/material'
import Typography from '@mui/material/Typography'
import {Traduction} from '../composants/Traduction'
import {CONSTANTES} from '../constantes/constantes'

/**
 * Composant affichant le titre de l'application
 * @param navigate
 * @returns {JSX.Element}
 * @constructor
 */
export const AfficherTitre = ({navigate}) => (
  <Button
    size={'large'}
    edge={'start'}
    color={'inherit'}
    onClick={() => navigate(CONSTANTES.routes.root)}
  >
    <Typography variant={'h6'} noWrap>
      <Traduction message={'titre'} />
    </Typography>
  </Button>
)
