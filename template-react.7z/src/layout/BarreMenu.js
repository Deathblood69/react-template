import React from 'react'
import AppBar from '@mui/material/AppBar'
import Toolbar from '@mui/material/Toolbar'
import {Outlet, useNavigate} from 'react-router'
import {Grid, IconButton} from '@mui/material'
import {AfficherTitre} from './AfficherTitre'
import {ChangementTheme} from './ChangementTheme'
import {ChangementLangage} from './ChangementLangage'
import {EventNote} from '@mui/icons-material'
import {ChoixToken} from './ChoixToken'
import {AfficherPatchnotes} from './AfficherPatchnotes'

/**
 * Composant affichant la barre principale de l'application
 * @returns {JSX.Element}
 * @constructor
 */
export default function BarreMenu() {
  const navigate = useNavigate()

  const handlePatchnotes = () => {
    navigate('/patchnotes')
  }

  return (
    <React.Fragment>
      <AppBar position="static" style={{zIndex: 10}}>
        <Toolbar>
          <Grid
            container
            spacing={2}
            alignItems={'center'}
            alignContent={'center'}
          >
            <Grid item sx={{flexGrow: 1, display: {xs: 'none', sm: 'block'}}}>
              <AfficherTitre navigate={navigate} />
            </Grid>
            <Grid item xs={'auto'}>
              <ChoixToken />
            </Grid>
            <Grid item xs={'auto'}>
              <ChangementTheme />
            </Grid>
            <Grid item xs={'auto'}>
              <ChangementLangage />
            </Grid>
            <Grid item xs={'auto'}>
              <AfficherPatchnotes handlePatchnotes={handlePatchnotes} />
            </Grid>
          </Grid>
        </Toolbar>
      </AppBar>
      <Outlet />
    </React.Fragment>
  )
}
