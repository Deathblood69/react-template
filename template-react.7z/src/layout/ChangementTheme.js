import {IconButton} from '@mui/material'
import {DarkMode, WbSunnyOutlined} from '@mui/icons-material'
import {useTheme} from '../provider/ThemeProvider'
import {useAlert} from '../provider/AlertProvider'
import {useTranslation} from 'react-i18next'

/**
 * Composant affichant le titre de l'application
 * @returns {JSX.Element}
 * @constructor
 */
export const ChangementTheme = () => {
  const {t} = useTranslation()

  const addAlert = useAlert()

  const {isDarkTheme, toggleTheme} = useTheme()

  const handleTheme = () => {
    toggleTheme()
    addAlert('success', t('succes'), t('theme'))
  }

  return (
    <IconButton onClick={handleTheme} style={{color: 'white'}}>
      {isDarkTheme ? <DarkMode /> : <WbSunnyOutlined />}
    </IconButton>
  )
}
