import {IconButton} from '@mui/material'
import {EventNote} from '@mui/icons-material'
import React from 'react'

export const AfficherPatchnotes = ({handlePatchnotes}) => (
  <IconButton onClick={handlePatchnotes} style={{color: 'white'}}>
    <EventNote />
  </IconButton>
)
