import {IconButton} from '@mui/material'
import {Language} from '@mui/icons-material'
import {useAlert} from '../provider/AlertProvider'
import {useTranslation} from 'react-i18next'

/**
 * Composant affichant le titre de l'application
 * @returns {JSX.Element}
 * @constructor
 */
export const ChangementLangage = () => {
  const {t, i18n} = useTranslation()

  const addAlert = useAlert()

  const handleTheme = () => {
    i18n.changeLanguage(i18n.language === 'fr' ? 'en' : 'fr').then(() => {
      addAlert('success', t('succes'), t('langue'))
    })
  }

  return (
    <IconButton onClick={handleTheme} style={{color: 'white'}}>
      <Language />
    </IconButton>
  )
}
