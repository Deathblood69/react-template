import React, {createContext, useContext, useEffect, useState} from 'react'
import {CssBaseline, ThemeProvider} from '@mui/material'
import {useStateLocalStorage} from '../hook/useStateLocalStorage'
import {CONSTANTES} from '../constantes/constantes'

/**
 * Provider permettant de choisir le thème dans toute l'application
 * @returns {JSX.Element}
 * @constructor
 */
export const CustomThemeProvider = ({children}) => {
  // ====== VARIABLES ====== //

  /** UseState qui permet de savoir si le thème afficher est le thème sombre */
  const [isDarkTheme, setIsDarkTheme] = useStateLocalStorage('darkTheme', false)

  /** UseState qui contient le thème à afficher */
  const [theme, setTheme] = useState(isDarkTheme ? themeSombre : themeClair)

  // ====== METHODES ====== //

  /** Méthode permettant de changer le thème affiché */
  const toggleTheme = () => {
    setTheme(isDarkTheme ? themeClair : themeSombre)
  }

  // ====== USE EFFECT ====== //

  /** useEffect permetant de vérifier si le thème est sombre ou clair */
  useEffect(() => {
    setIsDarkTheme(theme === themeSombre)
  }, [setIsDarkTheme, theme])

  // ====== AFFICHAGE ====== //

  return (
    <ThemeContext.Provider
      value={{theme, isDarkTheme, toggleTheme: toggleTheme}}
    >
      <CssBaseline />
      <ThemeProvider theme={theme}>{children}</ThemeProvider>
    </ThemeContext.Provider>
  )
}

/**
 * Thème sombre de l'application
 * @type *
 */
const themeSombre = CONSTANTES.themes.darkTheme

/**
 * Thème clair de l'application
 * @type *
 */
const themeClair = CONSTANTES.themes.lightTheme

/**
 * Contexte permettant d'appeler le provider
 * @type {React.Context<*>}
 */
export const ThemeContext = createContext(themeSombre)

/**
 * Hook permettant d'appeler le thème
 * @returns {*}
 */
export const useTheme = () => {
  return useContext(ThemeContext)
}
