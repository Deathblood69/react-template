import React, {createContext, useContext} from 'react'
import {useStateSessionStorage} from '../hook/useStateSessionStorage'

/**
 * Provider permettant d'afficher de connaitre l'utilisateur connecté
 * @returns {JSX.Element}
 * @constructor
 */
export const UtilisateurProvider = ({children}) => {
  // ====== VARIABLES ====== //

  /** useState qui contient l'utilisateur connecté */
  const [utilisateur, setUtilisateur] = useStateSessionStorage(
    'user',
    defautUser,
  )

  // ====== AFFICHAGE ====== //

  return (
    <UserContext.Provider value={{user: utilisateur, setUser: setUtilisateur}}>
      {children}
    </UserContext.Provider>
  )
}

/**
 * Utilisateur par défaut
 * @type *
 */
const defautUser = {
  identifiant: 'Inconnu',
}

export const UserContext = createContext(defautUser)

export const useUtilisateur = () => {
  return useContext(UserContext)
}
