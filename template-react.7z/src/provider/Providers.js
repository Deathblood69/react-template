import React from 'react'
import '../locales/i18n'
import {AlertProvider} from './AlertProvider'
import {UtilisateurProvider} from './UtilisateurProvider'
import {CssBaseline} from '@mui/material'
import {CustomThemeProvider} from './ThemeProvider'
import {BrowserRouter} from 'react-router-dom'
import {QueryClient, QueryClientProvider} from '@tanstack/react-query'

/**
 * Composant permettant de fournir des contextes à l'application
 * @returns {JSX.Element}
 * @constructor
 */
export const Providers = ({children}) => (
  <BrowserRouter>
    <QueryClientProvider client={queryClient}>
      <CustomThemeProvider>
        <CssBaseline />
        <AlertProvider>
          <UtilisateurProvider>{children}</UtilisateurProvider>
        </AlertProvider>
      </CustomThemeProvider>
    </QueryClientProvider>
  </BrowserRouter>
)

const queryClient = new QueryClient()
