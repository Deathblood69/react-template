import React from 'react'
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from '@mui/material'

export const AlertDialog = ({
  open = false,
  maxWidth = 'xl',
  handleOpen,
  titre,
  contenu,
}) => (
  <Dialog open={open} onClose={handleOpen} maxWidth={maxWidth}>
    <DialogTitle>{titre}</DialogTitle>
    <DialogContent>
      <DialogContentText style={{whiteSpace: 'pre'}}>
        {contenu}
      </DialogContentText>
    </DialogContent>
    <DialogActions>
      <Button onClick={handleOpen} color="primary">
        {'OK'}
      </Button>
    </DialogActions>
  </Dialog>
)
