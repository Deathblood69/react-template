import React from 'react'
import {Button, Grid, Typography} from '@mui/material'

/**
 * Composant permettant d'afficher les erreurs reçues par l'application
 * @param resetErrorBoundary Fonction à executer au rechargement de l'application
 * @param icone Icone à afficher sur la page d'erreur
 * @param titre
 * @param message Message à afficher sous l'icone
 * @param messageBouton Message sur le bouton rechargeant la page
 * @returns {JSX.Element}
 * @constructor
 */
export function PageErreur({
  resetErrorBoundary,
  icone,
  titre,
  message,
  messageBouton,
}) {
  return (
    <Grid
      container
      spacing={2}
      justifyContent={'center'}
      alignItems={'center'}
      style={{height: 'calc(100vh - 64px)'}}
    >
      <Grid item xs={4} container spacing={2}>
        <Grid item xs={12}>
          <img src={icone} className="logo" alt="logo" />
        </Grid>
        <Grid item xs={12}>
          <Typography variant={'h4'} align={'center'}>
            {titre}
          </Typography>
        </Grid>
        <Grid item xs={12}>
          <Typography align={'center'}>{message}</Typography>
        </Grid>
        <Grid item xs={12} container justifyContent={'center'}>
          <Button
            variant={'contained'}
            style={{maxWidth: '50%'}}
            onClick={resetErrorBoundary}
          >
            {messageBouton}
          </Button>
        </Grid>
      </Grid>
    </Grid>
  )
}
