import React from 'react'
import {Alert} from '@mui/material'

/** Composant permettant d'afficher un composant selon une condition
 * @param {boolean} condition - Condition validant l'affichage
 * @param {JSX.Element} children - Composant à afficher
 * @param {String} messageEchec - Message d'erreur si la condition est fausse
 * @param {JSX.Element} composantEchec - Composant à afficher si la condition est fausse
 * @returns {JSX.Element} - Composant
 */
function AfficherComposant({
  condition = false,
  children,
  messageEchec,
  composantEchec,
  severity = 'warning',
}) {
  return Boolean(condition) ? (
    children ?? <></>
  ) : (
    <React.Fragment>
      {messageEchec && (
        <Alert align={'center'} severity={severity}>
          {messageEchec}
        </Alert>
      )}
      {composantEchec}
    </React.Fragment>
  )
}

export default AfficherComposant
