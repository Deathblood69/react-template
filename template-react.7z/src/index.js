import React from 'react'
import ReactDOM from 'react-dom/client'
import {Template} from './pages/Template'
import {Providers} from './provider/Providers'
import {ErrorBoundary} from 'react-error-boundary'
import {PageErreur} from './composants/PageErreur/PageErreur'
import logo from './images/logo.svg'
import {useTranslation} from 'react-i18next'

/** Permet de récupérer l'élément root dans le DOM */
const root = ReactDOM.createRoot(document.getElementById('root'))

const ComposantErreur = () => {
  const {t} = useTranslation()

  const handleNavigate = () => window.location.reload()

  return (
    <PageErreur
      titre={t('page.erreur_titre')}
      message={t('page.erreur_message')}
      messageBouton={t('page.erreur_bouton')}
      icone={logo}
      resetErrorBoundary={handleNavigate}
    />
  )
}

/** Affiche les élément dans l'élement root du DOM */
root.render(
  <ErrorBoundary FallbackComponent={ComposantErreur}>
    <Providers>
      <Template />
    </Providers>
  </ErrorBoundary>,
)
