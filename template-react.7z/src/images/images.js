import logo from './logo.svg'

/**
 * Liste des images utilisées dans l'application
 * @type {{logo: *}}
 */
export const IMAGES = {
  logo,
}
