import {CONSTANTES} from '../constantes/constantes'
import {TYPE_REQUEST} from './api-generique'

export const randomNumber = (min, max) => {
  return Math.floor(Math.random() * (max - min + 1) + min)
}

let utilisateurs = Object.keys(CONSTANTES.utilisateurs).map(
  key => CONSTANTES.utilisateurs[key],
)

let profils = Object.keys(CONSTANTES.profils).map(
  key => CONSTANTES.profils[key],
)

let droits = Object.keys(CONSTANTES.droits).map(key => CONSTANTES.droits[key])

export const fakeFetch = (method, entity, pathParam, data) => {
  const delai = randomNumber(500, 2500)
  const id = pathParam.split('/').slice(1)[0]
  return new Promise(resolve => {
    setTimeout(() => {
      let res = []
      switch (entity) {
        case CONSTANTES.entities.droits:
          if (method === TYPE_REQUEST.DELETE) {
            droits = droits.filter(u => u.id !== Number(id))
          } else {
            res = droits
          }
          break
        case CONSTANTES.entities.profils:
          if (method === TYPE_REQUEST.DELETE) {
            profils = profils.filter(u => u.id !== Number(id))
          } else {
            res = profils
          }
          break
        case CONSTANTES.entities.utilisateurs:
          res = fetchData(method, res, data, id, utilisateurs)
          break
        default:
          res = []
      }
      resolve(res)
    }, delai)
  })
}

const fetchData = (method, res, data, id, array) => {
  switch (method) {
    case TYPE_REQUEST.GET:
      if (id) {
        res = array.find(e => e.id === id)
      } else {
        res = array
      }
      break
    case TYPE_REQUEST.POST:
      const newArray = [...array]
      const nextId =
        array.length > 0
          ? array
              .map(u => u.id)
              .reduce(function (a, b) {
                return Math.max(a, b)
              }) + 1
          : 0

      newArray.push({
        ...data,
        id: nextId,
      })
      array = newArray
      break
    case TYPE_REQUEST.PUT:
      const index = array.findIndex(u => u.id === Number(id))
      let firstPart = array.slice(0, index)
      const secondPart = array.slice(
        index !== array.length ? index + 1 : array.length,
      )
      array = firstPart.concat([data]).concat(secondPart)
      break
    case TYPE_REQUEST.DELETE:
      array = array.filter(u => u.id !== Number(id))
      break
    default:
      res = []
  }
  return res
}
