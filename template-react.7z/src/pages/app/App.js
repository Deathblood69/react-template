import React from 'react'
import {IMAGES} from '../../images/images'
import './css/App.css'
import {Traduction} from '../../composants/Traduction'
import {useTranslation} from 'react-i18next'
import {Grid, Typography} from '@mui/material'

/**
 * Composant affichant la page d'accueil de l'application
 * @returns {JSX.Element}
 * @constructor
 */
export const App = () => {
  const {t} = useTranslation()

  return (
    <Grid
      container
      spacing={2}
      justifyContent={'center'}
      alignItems={'center'}
      style={{height: 'calc(100vh - 64px)'}}
    >
      <Grid item xs={4} container spacing={2}>
        <Grid item xs={12} container justifyContent={'center'}>
          <img src={IMAGES.logo} className="App-logo" alt="logo" />
        </Grid>
        <Grid item xs={12} container justifyContent={'center'}>
          <Typography align={'center'}>
            {t('app.modifier')} <code>{'src/pages/app/App.js'}</code>{' '}
            {t('app.saveAndReload')}
          </Typography>
        </Grid>
        <Grid item xs={12} container justifyContent={'center'}>
          <a
            id={'apprendre-react'}
            className={'App-link'}
            href={'https://reactjs.org'}
            target={'_blank'}
            rel={'noopener noreferrer'}
          >
            <Traduction message={'app.apprendreReact'} />
          </a>
        </Grid>
      </Grid>
    </Grid>
  )
}
