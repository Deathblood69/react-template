import React from 'react'
import {App} from '../App'
import renderer from 'react-test-renderer'
import {render, fireEvent, screen} from '@testing-library/react'

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => {
    return {
      t: str => str,
      i18n: {
        changeLanguage: () => new Promise(() => {}),
      },
    }
  },
}))

test('Test de rendu', () => {
  // const rendu = renderer.create(<App />)
  // let tree = rendu.toJSON()
  // console.dir(tree)

  render(<App />)

  const lien = screen.getByText('app.apprendreReact')

  console.info(lien)

  fireEvent.click(lien)

  expect(lien).not.toBeUndefined()
})
