import React from 'react'
import {
  Button,
  CircularProgress,
  List,
  ListItem,
  ListItemText,
} from '@mui/material'
import {
  useCreate,
  useDelete,
  useGetById,
  useInvalidateQueries,
  useUpdate,
} from '../../api/api-generique'
import {CONSTANTES_PROFILS} from '../../constantes/constantes-profils'
import {CONSTANTES} from '../../constantes/constantes'
import AfficherComposant from '../../composants/AfficherComposant'

export const Utilisateurs = () => {
  const entity = CONSTANTES.entities.utilisateurs

  /** Requête qui permet de créer un utilisateur en bdd */
  const {mutateAsync: createUser} = useCreate(entity, [entity])

  /** Requête qui permet de modifier un utilisateur en bdd */
  const {mutateAsync: updateUser} = useUpdate(entity, [entity])

  const {mutateAsync: deleteUser} = useDelete(entity, [entity])

  const {mutateAsync: invalidate} = useInvalidateQueries()

  /** Permet d'effectuer une requête en bdd pour récupérer les utilisateurs selon la recherche  */
  const {data: getUtilisateurs, isFetching} = useGetById(entity, [entity])

  const handleCreate = () => {
    const utilisateur = {
      identifiant: 'p.mauconduit',
      nom: 'MAUCONDUIT',
      prenom: 'Paul',
      profil: CONSTANTES_PROFILS.utilisateur.id,
    }
    createUser(utilisateur)
  }

  const handleUpdate = () => {
    const data = {
      ...getUtilisateurs[getUtilisateurs.length - 1],
      identifiant: 'romain.diasparra',
    }
    updateUser(data)
  }

  const handleDelete = () => {
    const utilisateur = getUtilisateurs[getUtilisateurs.length - 1]
    deleteUser(utilisateur)
  }

  const handleGetAll = () => {
    invalidate([entity])
  }

  return (
    <React.Fragment>
      <Button onClick={handleCreate}>Create</Button>
      <Button onClick={handleUpdate}>Update</Button>
      <Button onClick={handleDelete}>Delete</Button>
      <Button onClick={handleGetAll}>Fetch</Button>
      <AfficherComposant
        condition={!isFetching && getUtilisateurs}
        composantEchec={<CircularProgress />}
      >
        <List>
          {getUtilisateurs?.map((utilisateur, index) => (
            <ListItem key={index}>
              <ListItemText
                primary={`${utilisateur.id}, ${utilisateur.identifiant}, ${utilisateur.nom}, ${utilisateur.prenom}`}
              />
            </ListItem>
          ))}
        </List>
      </AfficherComposant>
    </React.Fragment>
  )
}
