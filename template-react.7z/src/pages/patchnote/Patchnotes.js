import React from 'react'
import patchnote from './patchnote.json'
import {
  AddCircleOutline,
  AutorenewOutlined,
  BugReportOutlined,
  DeleteForeverOutlined,
  TrendingFlatOutlined,
  TrendingUpOutlined,
  UpdateOutlined,
} from '@mui/icons-material'
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Grid,
  Typography,
  useTheme,
} from '@mui/material'

export default function Patchnotes() {
  const theme = useTheme()

  const [expanded, setExpanded] = React.useState(false)

  const handleChange = panel => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false)
  }

  return (
    <Grid sx={{padding: '1%'}}>
      {patchnote.patchnote.map((note, i) => (
        <Accordion
          key={note.id}
          square
          expanded={expanded === note || (i === 0 && !expanded)}
          onChange={handleChange(note)}
        >
          <AccordionSummary
            aria-controls="panel1d-content"
            id={note.id}
            sx={{
              backgroundColor: theme.palette.primary.main,
              color: theme.palette.primary.contrastText,
            }}
          >
            <Typography>
              {note.nom} v{note.version}
            </Typography>
          </AccordionSummary>
          <AccordionDetails sx={{display: 'block'}}>
            {note.messages.map((message, index) => (
              <Typography
                key={`${note.id}-${index}`}
                sx={{
                  display: 'flex',
                  alignContent: 'center',
                  padding: theme.spacing(1),
                }}
              >
                <Grid sx={{marginRight: '10px'}}>{getTag(message.tag)}</Grid>
                <Grid>{message.texte}</Grid>
              </Typography>
            ))}
          </AccordionDetails>
        </Accordion>
      ))}
    </Grid>
  )
}

/**
 * Retourne l'icone associé au tag.
 * @param {any} tag le tag
 * @returns {*} icone
 */
function getTag(tag) {
  switch (tag) {
    case 'maj':
      return <UpdateOutlined />
    case 'min':
      return <TrendingFlatOutlined />
    case 'fix':
      return <BugReportOutlined />
    case 'add':
      return <AddCircleOutline />
    case 'del':
      return <DeleteForeverOutlined />
    case 'cur':
      return <AutorenewOutlined />
    default:
      return <TrendingUpOutlined />
  }
}
