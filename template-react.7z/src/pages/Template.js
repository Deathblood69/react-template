import React from 'react'
import {Route, Routes} from 'react-router-dom'
import {PageErreur} from '../composants/PageErreur/PageErreur'
import BarreMenu from '../layout/BarreMenu'
import {App} from './app/App'
import {useNavigate} from 'react-router'
import {useTranslation} from 'react-i18next'
import Patchnotes from './patchnote/Patchnotes'
import {CONSTANTES} from '../constantes/constantes'
import {IMAGES} from '../images/images'
import {Utilisateurs} from './utilisateurs/Utilisateurs'

/**
 * Composant principal de l'application, permet de gérer les routes et l'agencement
 * @returns {JSX.Element}
 * @constructor
 */
export const Template = () => {
  // ====== PARAMETRAGE ====== //

  const navigate = useNavigate()

  /** Hook de traduction */
  const {t} = useTranslation()

  const handleNavigate = () => navigate(-1)

  // ====== AFFICHAGE ====== //

  return (
    <Routes>
      <Route path={CONSTANTES.routes.root} element={<BarreMenu />}>
        <Route index element={<App />} />
        <Route path={CONSTANTES.routes.patchnote} element={<Patchnotes />} />
        <Route
          path={CONSTANTES.routes.utilisteurs}
          element={<Utilisateurs />}
        />
        <Route
          path={CONSTANTES.routes.notFound}
          element={
            <PageErreur
              titre={t('page.absent_titre')}
              message={t('page.absent_message')}
              messageBouton={t('page.absent_bouton')}
              icone={IMAGES.logo}
              resetErrorBoundary={handleNavigate}
            />
          }
        />
      </Route>
    </Routes>
  )
}
