import {CONSTANTES_PROFILS} from './constantes-profils'

export const CONSTANTES_UTILISATEURS = {
  inconnu: {
    id: 1,
    identifiant: 'inconnu',
    nom: 'INCONNU',
    prenom: 'Inconnu',
    profil: CONSTANTES_PROFILS.inconnu.id,
  },
  user1: {
    id: 2,
    identifiant: 'r.diasparra',
    nom: 'DIASPARRA',
    prenom: 'Romain',
    profil: CONSTANTES_PROFILS.administrateur.id,
  },
  user2: {
    id: 3,
    identifiant: 'm.boidin',
    nom: 'BOIDIN',
    prenom: 'Mathis',
    profil: CONSTANTES_PROFILS.utilisateur.id,
  },
  user3: {
    id: 4,
    identifiant: 'k.hougue',
    nom: 'HOUGUE',
    prenom: 'Kévin',
    profil: CONSTANTES_PROFILS.utilisateur.id,
  },
}
