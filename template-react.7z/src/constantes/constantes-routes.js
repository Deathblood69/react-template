/**
 * List des chemins globaux de l'application
 * @type *
 */
export const CONSTANTES_ROUTES = {
  root: '/',
  patchnote: 'patchnotes',
  notFound: '*',
  utilisteurs: 'utilisateurs',
}
