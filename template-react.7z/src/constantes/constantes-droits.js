export const CONSTANTES_DROITS = {
  changerTheme: {
    id: 'changerTheme',
    nom: 'Changer le thème',
    description: 'Afficher un thème sombre à la place du thème clair',
  },
  changerLangue: {
    id: 'changerLangue',
    nom: 'Changer la langue',
    description: "Changer la langue affichée dans l'application",
  },
}
