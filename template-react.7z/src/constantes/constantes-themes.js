import {createTheme} from '@mui/material/styles'

/**
 * Liste des thèmes disponible au sein de l'application
 * @type *
 */
export const CONSTANTES_THEMES = {
  darkTheme: createTheme({
    palette: {
      mode: 'dark',
    },
  }),
  lightTheme: createTheme({
    palette: {
      mode: 'light',
    },
  }),
}
