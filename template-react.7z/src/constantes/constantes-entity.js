export const CONSTANTES_ENTITIES = {
  droits: 'droits',
  profils: 'profils',
  utilisateurs: 'utilisateurs',
}
