import {CONSTANTES_DROITS} from './constantes-droits'

export const CONSTANTES_PROFILS = {
  utilisateur: {
    id: 'utilisateur',
    nom: 'Utilisateur',
    droits: [
      CONSTANTES_DROITS.changerTheme.id,
      CONSTANTES_DROITS.changerLangue.id,
    ],
  },
  administrateur: {
    id: 'administrateur',
    nom: 'Adminitrateur',
    droits: [
      CONSTANTES_DROITS.changerTheme.id,
      CONSTANTES_DROITS.changerLangue.id,
    ],
  },
  inconnu: {
    id: 'inconnu',
    nom: 'Inconnu',
  },
}
