import {CONSTANTES_THEMES} from './constantes-themes'
import {CONSTANTES_UTILISATEURS} from './constantes-utilisateurs'
import {CONSTANTES_ROUTES} from './constantes-routes'
import {CONSTANTES_PROFILS} from './constantes-profils'
import {CONSTANTES_DROITS} from './constantes-droits'
import {CONSTANTES_ENTITIES} from './constantes-entity'

export const CONSTANTES = {
  routes: CONSTANTES_ROUTES,
  themes: CONSTANTES_THEMES,
  droits: CONSTANTES_DROITS,
  profils: CONSTANTES_PROFILS,
  utilisateurs: CONSTANTES_UTILISATEURS,
  entities: CONSTANTES_ENTITIES,
}
