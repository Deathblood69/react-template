// home_page.spec.js created with Cypress
//
// Start writing your Cypress tests below!
// If you're unfamiliar with how Cypress works,
// check out the link below and learn how to write your first test:
// https://on.cypress.io/writing-first-test

describe('Visite de la page intradef', () => {
  it('Redirection vers la page intradef', () => {
    cy.visit('http://portail.intradef.gouv.fr/')
  })
})
